RESERVED_KEYWORDS = {
  'HEADER_FUNC': 'function',
  'HEADER_PROGRAM': 'program',
  'IF': 'if',
  'WHILE': 'while',
  'HEADER_PROC': 'procedure',
  'INT': 'int',
  'BOOL': 'bool',
  'ELSE': 'else',
  'INPUT': 'input',
  'PRINT': 'print',
  'BREAK': 'break',
  'CONTINUE': 'continue',
  'RETURN': 'return'
}